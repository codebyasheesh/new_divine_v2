<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmailTemplate extends Model
{
    protected $fillable = [
        'template_key',
        'template_name',
        'subject',
        'body',
        'status'
    ];
}
